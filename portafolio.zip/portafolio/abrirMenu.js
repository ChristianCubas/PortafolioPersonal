let menu = document.getElementById("menu")
let navegacion = document.getElementById("navegacion")
let cont = 0

function abrirMenu(){

    let bajada = document.getElementById("bajar")
    if(cont % 2 === 0){
        navegacion.style.display='block'
        bajada.style.display='none'
        cont++
        console.log(cont)
    }else{
        navegacion.style.display='none'
        bajada.style.display='block'
        cont++
        console.log(cont)
    }
}

menu.addEventListener('click',abrirMenu)

let items = document.getElementById("items")
items.addEventListener('click',()=>{
    if(window.innerWidth<=1020){
        navegacion.style.display='none'
        cont++
    }
})