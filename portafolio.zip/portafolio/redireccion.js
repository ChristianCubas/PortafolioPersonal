let api = document.getElementById("ctn1")
let escenario  = document.getElementById("ctn2")
let tailwind = document.getElementById("ctn3")
let carrito  = document.getElementById("ctn4")
let pendientes = document.getElementById("ctn5")

function abrirApi(){
    window.open("https://github.com/ChristianCubas/Consumo_API_RickyMorty")
}

function abrirEscenario(){
    window.open("https://github.com/ChristianCubas/Escenario-3D")
}

function abrirTailwind(){
    window.open("https://github.com/ChristianCubas/Tailwind_Practica")
}

function abrirPendientes(){
    window.open("https://github.com/ChristianCubas/ListadoPendientes")
}

function personal(){
    window.open("./privado.html")
}

api.addEventListener('click',abrirApi)
escenario.addEventListener('click',abrirEscenario)
tailwind.addEventListener('click',abrirTailwind)
pendientes.addEventListener('click',abrirPendientes)
carrito.addEventListener('click',personal)
