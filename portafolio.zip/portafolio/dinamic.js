gsap.registerPlugin(ScrollTrigger);

const tl = gsap.timeline()

tl.from('#sobctn2', {x:'100%'})
tl.from('#sobctn3', {x:'-100%'})

ScrollTrigger.create({
    animation:tl,
    trigger:'#sobremi',
    start:'top top',
    end:'+=4000',
    pin:true,
    scrub:true,
})
